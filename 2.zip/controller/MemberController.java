package com.example.cumstproject.controller;

import com.example.cumstproject.domain.Member;
import com.example.cumstproject.domain.dto.MemberDto;
import com.example.cumstproject.repository.MemberRepository;
import com.example.cumstproject.service.MemberService;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.util.Optional;

@Slf4j
@Controller
@RequiredArgsConstructor
public class MemberController {

    private final MemberService memberService;
    private final MemberRepository memberRepository;

    // 회원가입
    @GetMapping("/memberRegister")
    public String createForm(Model model, MemberDto memberDto) {
        model.addAttribute("memberForm", memberDto);
        return "member/register";
    }

    // 회원가입 post
    @PostMapping("/memberRegister/")
    public String memberSignUp(HttpSession session,
                               @Valid MemberDto form,
                               Member member1,
                               BindingResult result,
                               HttpServletResponse response) {

        if (result.hasErrors()) {
            log.info("error!");
            return "member/register";
        }

        if (!form.getPw().equals(form.getPw2())) {
            try {
                response.setContentType("text/html; charset=utf-8");
                PrintWriter w = response.getWriter();
                w.write("<script>alert('" + "비밀번호가 다릅니다." + "');history.go(-1);</script>");
                w.flush();
                w.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            log.info(">>> 다시 시도해 주세요. <<<");
            return "member/register";
        }


        Member member = new Member();
        member.setName(form.getName());
        member.setPw(form.getPw());
        member.setLocalDateTime(LocalDateTime.now());

        Optional<Member> dupMember = memberRepository.findByName(member1.getName());
        if(dupMember.isPresent()){
            if(member.getName().equals(dupMember.get().getName())){
                try {
                    response.setContentType("text/html; charset=utf-8");
                    PrintWriter w = response.getWriter();
                    w.write("<script>alert('" + "중복된 아이디 입니다." + "');history.go(-1);</script>");
                    w.flush();
                    w.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                log.info(">>> 중복된 아이디 입니다. <<<");
                return "member/register";
            }
        }


        session.setAttribute("memberInfo", member);
        memberService.save(member);

        return "redirect:/";
    }

    // 로그인
    @GetMapping("/memberLogin")
    public String login() {
        return "member/login";
    }

    // 로그인 post
    @PostMapping("/memberLogin/")
    public String memberSingIn(@Valid MemberDto form,
                               Member member,
                               HttpServletResponse response,
                               HttpSession session) {
        Optional<Member> test = memberRepository.findByNameAndPw(member.getName(), member.getPw());
        log.info("[LoginController] loginTest() >> user = {}", test);
        if (test.isEmpty()) {
            try {
                response.setContentType("text/html; charset=utf-8");
                PrintWriter w = response.getWriter();
                w.write("<script>alert('" + "아이디 비밀번호를 확인하세요." + "');history.go(-1);</script>");
                w.flush();
                w.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return "member/login";
        } else {
            test.ifPresent(e -> {
                log.info("login");
            });
            session.setAttribute("memberInfo", test.get());
            return "redirect:/";
        }

    }

    // 로그아웃
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        log.info("logout");
        session.invalidate();
        return "redirect:/";
    }


}
