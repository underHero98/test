package com.example.cumstproject.controller;

import com.example.cumstproject.domain.Board;
import com.example.cumstproject.domain.Member;
import com.example.cumstproject.domain.dto.BoardDto;
import com.example.cumstproject.repository.MemberRepository;
import com.example.cumstproject.service.BoardService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.util.Optional;

@Slf4j
@Controller
@RequiredArgsConstructor
public class BoardController {

    private final BoardService boardService;
    private final MemberRepository memberRepository;

    // 글쓰기
    @GetMapping("/boardWrite")
    public String boardWrite(HttpServletResponse response,
                             HttpServletRequest request
    ) {

        Member member = (Member) request.getSession().getAttribute("memberInfo");

        if (member == null) {
            log.info(">>> 로그인 후 이용해 주세요. <<<");
            try {
                response.setContentType("text/html; charset=utf-8");
                PrintWriter w = response.getWriter();
                w.write("<script>alert('" + "로그인 후 이용해 주세요." + "');history.go(-1);</script>");
                w.flush();
                w.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return "member/login";
        }
        log.info(">>> boardWrite access <<<");
        return "board/boardWrite";
    }

    // 글쓰기 post
    @PostMapping("/boardWrite")
    public String write(@Valid BoardDto form,
                        HttpServletRequest request) {

        Member member = (Member) request.getSession().getAttribute("memberInfo");
        Member member1 = memberRepository.findByName(member.getName()).orElseThrow();

        Board board = Board.builder()
                .title(form.getTitle())
                .content(form.getContent())
                .localDateTime(LocalDateTime.now())
                .member(member1)
                .build();

        boardService.savePost(board);

        log.info(">>> write success!! <<<");
        return "redirect:/";
    }




}
