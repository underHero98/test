package com.example.cumstproject.service;

import com.example.cumstproject.domain.Board;
import com.example.cumstproject.repository.BoardRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Service
public class BoardService {

    private final BoardRepository boardRepository;

    public Long savePost(Board board){
        boardRepository.save(board);
        return board.getId();
    }



}
