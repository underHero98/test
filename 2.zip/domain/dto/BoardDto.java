package com.example.cumstproject.domain.dto;

import jakarta.validation.constraints.NotEmpty;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class BoardDto {

    private Long id;

    @NotEmpty(message = "제목입력은 필수 입니다.")
    private String title;

    @NotEmpty(message = "내용입력은 필수 입니다.")
    private String content;
    private LocalDateTime localDateTime;

    private Long memberId;
}
